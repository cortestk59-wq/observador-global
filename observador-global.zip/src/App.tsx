import { useEffect, useState } from 'react';
import { ArticleView } from './components/ArticleView';
import { Footer } from './components/Footer';
import { FrontPageView } from './components/FrontPageView';
import { Masthead } from './components/Masthead';
import { SubscribeModal } from './components/SubscribeModal';
import { ARTICLES, INITIAL_COMMENTS, LEAD_ARTICLE_ID } from './data/articles';
import { type ReaderComment, type SectionCategory } from './utils/editorial';

const STORAGE_SAVED_KEY = 'og_saved_articles_v1';
const STORAGE_COMMENTS_KEY = 'og_reader_comments_v1';
const STORAGE_VOTES_KEY = 'og_voted_comments_v1';
const STORAGE_SUB_KEY = 'og_subscribed_email_v1';

function readStorageJson<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [viewMode, setViewMode] = useState<'article' | 'frontpage'>('article');
  const [activeArticleId, setActiveArticleId] = useState<string>(LEAD_ARTICLE_ID);
  const [activeSection, setActiveSection] = useState<SectionCategory>('Games & Mídia');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlySaved, setOnlySaved] = useState(false);

  const [savedIds, setSavedIds] = useState<string[]>(() =>
    readStorageJson<string[]>(STORAGE_SAVED_KEY, [])
  );
  const [comments, setComments] = useState<ReaderComment[]>(() =>
    readStorageJson<ReaderComment[]>(STORAGE_COMMENTS_KEY, INITIAL_COMMENTS)
  );
  const [votedCommentIds, setVotedCommentIds] = useState<string[]>(() =>
    readStorageJson<string[]>(STORAGE_VOTES_KEY, [])
  );
  const [subscribedEmail, setSubscribedEmail] = useState<string | null>(() =>
    readStorageJson<string | null>(STORAGE_SUB_KEY, null)
  );
  const [subscribeModalOpen, setSubscribeModalOpen] = useState(false);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_SAVED_KEY, JSON.stringify(savedIds));
    } catch {
      // Ignore storage quota errors
    }
  }, [savedIds]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_COMMENTS_KEY, JSON.stringify(comments));
    } catch {
      // Ignore storage quota errors
    }
  }, [comments]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_VOTES_KEY, JSON.stringify(votedCommentIds));
    } catch {
      // Ignore storage quota errors
    }
  }, [votedCommentIds]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_SUB_KEY, JSON.stringify(subscribedEmail));
    } catch {
      // Ignore storage quota errors
    }
  }, [subscribedEmail]);

  const currentArticle =
    ARTICLES.find((article) => article.id === activeArticleId) ?? ARTICLES[0];

  const handleSelectSection = (section: SectionCategory) => {
    setActiveSection(section);
    setViewMode('frontpage');
    setOnlySaved(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectArticle = (articleId: string) => {
    const target = ARTICLES.find((a) => a.id === articleId);
    if (!target) return;
    setActiveArticleId(articleId);
    setActiveSection(target.section);
    setViewMode('article');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleSave = (articleId: string) => {
    setSavedIds((prev) =>
      prev.includes(articleId) ? prev.filter((id) => id !== articleId) : [...prev, articleId]
    );
  };

  const handleToggleCommentVote = (commentId: string) => {
    const alreadyVoted = votedCommentIds.includes(commentId);
    setVotedCommentIds((prev) =>
      alreadyVoted ? prev.filter((id) => id !== commentId) : [...prev, commentId]
    );
    setComments((prev) =>
      prev.map((comment) =>
        comment.id === commentId
          ? { ...comment, votes: comment.votes + (alreadyVoted ? -1 : 1) }
          : comment
      )
    );
  };

  const handleAddComment = (comment: ReaderComment) => {
    setComments((prev) => [comment, ...prev]);
    setVotedCommentIds((prev) => [...prev, comment.id]);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#161616]">
      <Masthead
        activeSection={activeSection}
        isFrontPage={viewMode === 'frontpage'}
        onSelectSection={handleSelectSection}
        onOpenSubscribe={() => setSubscribeModalOpen(true)}
        isSubscribed={Boolean(subscribedEmail)}
      />

      {viewMode === 'article' ? (
        <ArticleView
          article={currentArticle}
          allArticles={ARTICLES}
          isSaved={savedIds.includes(currentArticle.id)}
          onToggleSave={handleToggleSave}
          onSelectArticle={handleSelectArticle}
          onOpenFrontPage={() => handleSelectSection('Capa')}
          comments={comments}
          votedCommentIds={votedCommentIds}
          onToggleCommentVote={handleToggleCommentVote}
          onAddComment={handleAddComment}
        />
      ) : (
        <FrontPageView
          articles={ARTICLES}
          activeSection={activeSection}
          searchQuery={searchQuery}
          onlySaved={onlySaved}
          savedIds={savedIds}
          onSearchChange={setSearchQuery}
          onToggleOnlySaved={() => setOnlySaved((prev) => !prev)}
          onSelectSection={handleSelectSection}
          onSelectArticle={handleSelectArticle}
        />
      )}

      <Footer
        onSelectSection={handleSelectSection}
        onOpenSubscribe={() => setSubscribeModalOpen(true)}
      />

      <SubscribeModal
        open={subscribeModalOpen}
        subscribedEmail={subscribedEmail}
        onClose={() => setSubscribeModalOpen(false)}
        onSubscribe={(email) => setSubscribedEmail(email)}
      />
    </div>
  );
}
