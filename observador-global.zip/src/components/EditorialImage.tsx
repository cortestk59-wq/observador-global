import { useState } from 'react';
import { Camera } from 'lucide-react';
import { type ArticleImage } from '../utils/editorial';

interface EditorialImageProps {
  image: ArticleImage;
  aspectClass?: string;
  priority?: boolean;
}

export function EditorialImage({
  image,
  aspectClass = 'aspect-video',
  priority = false,
}: EditorialImageProps) {
  const [hasError, setHasError] = useState(false);

  return (
    <figure className="my-6">
      <div
        className={`relative w-full overflow-hidden bg-[#EBE6DF] border border-stone-200 ${aspectClass}`}
      >
        {!hasError ? (
          <img
            src={image.src}
            alt={image.alt}
            referrerPolicy="no-referrer"
            loading={priority ? 'eager' : 'lazy'}
            onError={() => setHasError(true)}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-stone-200 to-stone-300 p-6 text-center text-stone-600">
            <Camera className="h-7 w-7 stroke-[1.5]" aria-hidden="true" />
            <p className="max-w-md text-xs font-medium">{image.alt}</p>
          </div>
        )}
      </div>
      <figcaption className="mt-2.5 flex flex-col gap-1 border-b border-stone-200 pb-2.5 text-xs leading-relaxed text-stone-600 sm:flex-row sm:items-baseline sm:justify-between">
        <span className="font-serif italic text-stone-700">{image.caption}</span>
        <span className="shrink-0 text-[11px] text-stone-500 sm:pl-4">{image.credit}</span>
      </figcaption>
    </figure>
  );
}
