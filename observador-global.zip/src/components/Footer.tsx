import { type SectionCategory } from '../utils/editorial';

interface FooterProps {
  onSelectSection: (section: SectionCategory) => void;
  onOpenSubscribe: () => void;
}

const FOOTER_SECTIONS: SectionCategory[] = [
  'Capa',
  'Mercados',
  'Tecnologia',
  'Games & Mídia',
  'Regulação',
];

export function Footer({ onSelectSection, onOpenSubscribe }: FooterProps) {
  return (
    <footer className="mt-16 border-t border-stone-300 bg-[#F4F1EA] py-10 text-xs text-stone-600">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 border-b border-stone-300 pb-6 md:flex-row md:items-center">
          <div>
            <p className="font-serif text-lg font-bold text-[#161616]">Observador Global</p>
            <p className="mt-1 text-stone-500">
              Redação Central: Av. Paulista, 1374 — São Paulo · Correspondências em Nova York, Londres e Bruxelas
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-5">
            {FOOTER_SECTIONS.map((section) => (
              <button
                key={section}
                type="button"
                onClick={() => onSelectSection(section)}
                className="font-medium text-stone-700 hover:text-[#161616] hover:underline whitespace-nowrap"
              >
                {section}
              </button>
            ))}
            <button
              type="button"
              onClick={onOpenSubscribe}
              className="font-semibold text-[#1E3A8A] hover:underline whitespace-nowrap"
            >
              Boletim Matinal
            </button>
          </div>
        </div>

        <div className="mt-6 flex flex-col justify-between gap-2 text-[11px] text-stone-500 sm:flex-row">
          <p>© 2026 Observador Global S.A. · Todos os direitos reservados.</p>
          <p>Princípios Editoriais · Código de Conduta Jornalística · Expediente</p>
        </div>
      </div>
    </footer>
  );
}
