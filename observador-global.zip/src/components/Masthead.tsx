import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { type SectionCategory } from '../utils/editorial';

interface MastheadProps {
  activeSection: SectionCategory;
  isFrontPage: boolean;
  onSelectSection: (section: SectionCategory) => void;
  onOpenSubscribe: () => void;
  isSubscribed: boolean;
}

const NAV_SECTIONS: SectionCategory[] = [
  'Capa',
  'Mercados',
  'Tecnologia',
  'Games & Mídia',
  'Regulação',
];

export function Masthead({
  activeSection,
  isFrontPage,
  onSelectSection,
  onOpenSubscribe,
  isSubscribed,
}: MastheadProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (section: SectionCategory) => {
    onSelectSection(section);
    setMobileMenuOpen(false);
  };

  return (
    <div className="bg-[#FAF9F6] border-b border-stone-300">
      <header className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <a
          href="#capa"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick('Capa');
          }}
          className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#161616] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1E3A8A]"
        >
          Observador Global
        </a>

        {/* Zone 2: 5 concise single-line text nav links */}
        <nav
          aria-label="Seções principais"
          className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600"
        >
          {NAV_SECTIONS.map((section) => {
            const active =
              (isFrontPage && activeSection === section) ||
              (!isFrontPage && section !== 'Capa' && activeSection === section);

            return (
              <a
                key={section}
                href={`#${section.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(section);
                }}
                aria-current={active ? 'page' : undefined}
                className={`whitespace-nowrap shrink-0 py-1 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1E3A8A] ${
                  active
                    ? 'text-[#161616] underline decoration-[#1E3A8A] decoration-2 underline-offset-8'
                    : 'hover:text-[#161616] hover:underline hover:decoration-stone-400 hover:underline-offset-8'
                }`}
              >
                {section}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenSubscribe}
            className="hidden sm:inline-flex items-center justify-center rounded bg-[#161616] px-4 py-2 text-xs font-semibold text-white transition-colors duration-150 hover:bg-[#1E3A8A] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E3A8A]"
          >
            {isSubscribed ? 'Assinante' : 'Assinar'}
          </button>

          <button
            type="button"
            aria-label={mobileMenuOpen ? 'Fechar menu de seções' : 'Abrir menu de seções'}
            aria-expanded={mobileMenuOpen}
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="inline-flex h-10 w-10 items-center justify-center rounded border border-stone-300 text-[#161616] md:hidden hover:bg-stone-100 focus-visible:outline-2 focus-visible:outline-[#1E3A8A]"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="Menu móvel"
          className="border-t border-stone-200 bg-white px-4 py-3 md:hidden"
        >
          <div className="flex flex-col gap-1">
            {NAV_SECTIONS.map((section) => (
              <button
                key={section}
                type="button"
                onClick={() => handleNavClick(section)}
                className="flex min-h-[44px] w-full items-center justify-between border-b border-stone-100 px-2 text-left text-sm font-medium text-[#161616] last:border-b-0 hover:bg-stone-50"
              >
                <span>{section}</span>
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSubscribe();
              }}
              className="mt-2 min-h-[44px] w-full rounded bg-[#161616] px-4 py-2 text-center text-sm font-semibold text-white hover:bg-[#1E3A8A]"
            >
              {isSubscribed ? 'Gerenciar Assinatura' : 'Assinar Edição Digital'}
            </button>
          </div>
        </nav>
      )}

      {/* Editorial Dateline Strip (below header, static text metadata) */}
      <div className="border-t border-stone-200 bg-[#F4F1EA]">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-x-6 gap-y-1 px-4 py-2 text-xs text-stone-600 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
            <span className="font-medium text-stone-800">Segunda-feira, 16 de novembro de 2026</span>
            <span aria-hidden="true" className="hidden sm:inline">·</span>
            <span className="w-full sm:w-auto">São Paulo · Nova York · Bruxelas</span>
          </div>
          <div className="flex items-center gap-3 font-mono text-[11px] tabular-nums">
            <span>
              TTWO <strong className="font-semibold text-[#991B1B]">-14,82%</strong>
            </span>
            <span aria-hidden="true" className="text-stone-400">
              /
            </span>
            <span>
              IBOV <strong className="font-semibold text-[#14532D]">+0,42%</strong>
            </span>
            <span aria-hidden="true" className="text-stone-400">
              /
            </span>
            <span>
              USD/BRL <strong className="font-semibold text-stone-800">5,78</strong>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
