import { useState } from 'react';
import { Bookmark, Check, Share2, Type } from 'lucide-react';
import { LEAD_ARTICLE_ID } from '../data/articles';
import { type Article, type ReaderComment } from '../utils/editorial';
import { CommentsSection } from './CommentsSection';
import { EditorialImage } from './EditorialImage';
import { TechnicalDossier } from './TechnicalDossier';

interface ArticleViewProps {
  article: Article;
  allArticles: Article[];
  isSaved: boolean;
  onToggleSave: (articleId: string) => void;
  onSelectArticle: (articleId: string) => void;
  onOpenFrontPage: () => void;
  comments: ReaderComment[];
  votedCommentIds: string[];
  onToggleCommentVote: (commentId: string) => void;
  onAddComment: (comment: ReaderComment) => void;
}

export function ArticleView({
  article,
  allArticles,
  isSaved,
  onToggleSave,
  onSelectArticle,
  onOpenFrontPage,
  comments,
  votedCommentIds,
  onToggleCommentVote,
  onAddComment,
}: ArticleViewProps) {
  const [largeText, setLargeText] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const relatedArticles = allArticles.filter((item) => item.id !== article.id);

  const handleShare = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(window.location.href);
      }
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 2600);
    } catch {
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 2600);
    }
  };

  const proseSizeClass = largeText
    ? 'text-[18px] leading-[1.82]'
    : 'text-[16px] leading-[1.78]';

  return (
    <main className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-8">
      {/* Unboxed Breadcrumb / Kicker Line */}
      <div className="mb-4 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-stone-500">
        <button
          type="button"
          onClick={onOpenFrontPage}
          className="font-medium text-[#1E3A8A] hover:underline focus-visible:outline-2 focus-visible:outline-[#1E3A8A]"
        >
          Capa
        </button>
        <span aria-hidden="true">/</span>
        <span className="font-semibold text-[#161616]">{article.section}</span>
        <span aria-hidden="true">·</span>
        <span className={article.isBreaking ? 'font-semibold text-[#991B1B]' : 'text-stone-600'}>
          {article.kicker}
        </span>
      </div>

      {/* 70 / 30 Asymmetric Editorial Grid */}
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
        {/* Main Essay Column (8 cols ~ 67-70%) */}
        <article className="lg:col-span-8">
          <header className="border-b border-stone-200 pb-6">
            <h1 className="headline-balance font-serif text-3xl font-bold tracking-tight text-[#161616] sm:text-4xl lg:text-[2.65rem] lg:leading-[1.14]">
              {article.headline}
            </h1>

            <p className="mt-4 text-base leading-relaxed text-stone-700 sm:text-lg">
              {article.deck}
            </p>

            {/* Author Byline + Tools */}
            <div className="mt-6 flex flex-col gap-4 border-t border-stone-200 pt-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-xs leading-relaxed text-stone-600">
                <p className="font-semibold text-[#161616]">
                  Por {article.authors} <span className="font-normal text-stone-500">· {article.location}</span>
                </p>
                <p className="mt-0.5 tabular-nums text-stone-500">
                  {article.publishedAt}
                  {article.updatedAt ? ` · ${article.updatedAt}` : ''} · {article.readingMinutes} min de leitura
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setLargeText((prev) => !prev)}
                  aria-pressed={largeText}
                  aria-label="Alternar tamanho do texto da reportagem"
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded border border-stone-300 bg-white px-3 py-1.5 text-xs font-medium text-stone-700 transition-colors hover:border-stone-400 hover:text-[#161616] whitespace-nowrap shrink-0"
                >
                  <Type className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{largeText ? 'Texto padrão' : 'Ampliar texto'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onToggleSave(article.id)}
                  aria-pressed={isSaved}
                  className={`inline-flex min-h-[40px] items-center gap-1.5 rounded border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    isSaved
                      ? 'border-[#1E3A8A] bg-[#1E3A8A] text-white'
                      : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400 hover:text-[#161616]'
                  }`}
                >
                  <Bookmark className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{isSaved ? 'Salvo' : 'Salvar'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleShare}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded border border-stone-300 bg-white px-3 py-1.5 text-xs font-medium text-stone-700 transition-colors hover:border-stone-400 hover:text-[#161616] whitespace-nowrap shrink-0"
                >
                  {copiedLink ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-[#14532D]" aria-hidden="true" />
                      <span className="text-[#14532D]">Link copiado</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Compartilhar</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </header>

          {/* Lead Documentary Image */}
          <EditorialImage image={article.heroImage} aspectClass="aspect-video" priority />

          {/* Article Body Prose (constrained 65-75ch reading measure) */}
          <div className={`mx-auto max-w-prose space-y-5 text-[#1C1917] ${proseSizeClass}`}>
            {article.leadParagraphs.map((paragraph, index) => (
              <p
                key={`lead-${index}`}
                className={
                  index === 0
                    ? 'first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:font-serif first-letter:text-5xl first-letter:font-bold first-letter:leading-none first-letter:text-[#161616]'
                    : ''
                }
              >
                {paragraph}
              </p>
            ))}

            {/* Pull Quote with hairline top/bottom dividers */}
            {article.pullQuote && (
              <blockquote className="my-8 border-y border-stone-300 py-6 text-center">
                <p className="font-serif text-xl italic leading-relaxed text-[#161616] sm:text-2xl">
                  “{article.pullQuote.text}”
                </p>
                <footer className="mt-3 text-xs font-medium text-stone-500">
                  {article.pullQuote.attribution}
                </footer>
              </blockquote>
            )}

            {article.bodyParagraphs.map((paragraph, index) => (
              <p key={`body-${index}`}>{paragraph}</p>
            ))}
          </div>

          {/* Secondary Lab Photograph */}
          {article.secondaryImage && (
            <EditorialImage image={article.secondaryImage} aspectClass="aspect-video" />
          )}

          {/* Interactive Technical & Market Dossier on Lead Story */}
          {article.id === LEAD_ARTICLE_ID && <TechnicalDossier />}

          {/* Closing Prose */}
          {article.closingParagraphs.length > 0 && (
            <div className={`mx-auto max-w-prose space-y-5 text-[#1C1917] ${proseSizeClass}`}>
              {article.closingParagraphs.map((paragraph, index) => (
                <p key={`close-${index}`}>{paragraph}</p>
              ))}
            </div>
          )}

          {/* Reader Comments (shown on lead story or all articles) */}
          {article.id === LEAD_ARTICLE_ID && (
            <CommentsSection
              comments={comments}
              votedIds={votedCommentIds}
              onToggleVote={onToggleCommentVote}
              onAddComment={onAddComment}
            />
          )}
        </article>

        {/* Right Margin Rail (4 cols ~ 30%) */}
        <aside aria-label="Contexto e leituras relacionadas" className="lg:col-span-4">
          <div className="space-y-8 lg:sticky lg:top-6">
            {/* Market Metrics Card */}
            {article.marketMetrics && article.marketMetrics.length > 0 && (
              <section className="border border-stone-300 bg-white p-5">
                <h2 className="border-b border-stone-200 pb-3 font-serif text-lg font-semibold text-[#161616]">
                  Impacto imediato no mercado
                </h2>
                <dl className="mt-3 divide-y divide-stone-200 text-xs">
                  {article.marketMetrics.map((metric) => (
                    <div
                      key={metric.label}
                      className="flex items-start justify-between gap-4 py-2.5"
                    >
                      <dt className="text-stone-600 leading-snug">{metric.label}</dt>
                      <dd className="flex shrink-0 flex-col items-end text-right font-mono tabular-nums">
                        <span className="font-semibold text-[#161616] whitespace-nowrap">{metric.value}</span>
                        {metric.delta && (
                          <span
                            className={`mt-0.5 text-[11px] font-semibold whitespace-nowrap ${
                              metric.tone === 'negative'
                                ? 'text-[#991B1B]'
                                : metric.tone === 'positive'
                                  ? 'text-[#14532D]'
                                  : 'text-stone-500'
                            }`}
                          >
                            {metric.delta}
                          </span>
                        )}
                      </dd>
                    </div>
                  ))}
                </dl>
                <p className="mt-3 text-[11px] text-stone-500">
                  Dados consolidados às 10h10 (BRT). Cotações em dólar norte-americano.
                </p>
              </section>
            )}

            {/* Official Timeline */}
            {article.timeline && article.timeline.length > 0 && (
              <section className="border border-stone-300 bg-white p-5">
                <h2 className="border-b border-stone-200 pb-3 font-serif text-lg font-semibold text-[#161616]">
                  Cronologia do adiamento
                </h2>
                <ol className="mt-3 divide-y divide-stone-200">
                  {article.timeline.map((item) => (
                    <li key={item.date} className="py-3 first:pt-1 last:pb-0">
                      <p className="font-mono text-[11px] font-medium text-[#1E3A8A] tabular-nums">
                        {item.date}
                      </p>
                      <h3 className="mt-1 text-xs font-semibold text-[#161616]">{item.title}</h3>
                      <p className="mt-1 text-xs leading-relaxed text-stone-600">{item.detail}</p>
                    </li>
                  ))}
                </ol>
              </section>
            )}

            {/* Most Read / Related Articles */}
            <section className="border border-stone-300 bg-white p-5">
              <div className="flex items-baseline justify-between border-b border-stone-200 pb-3">
                <h2 className="font-serif text-lg font-semibold text-[#161616]">
                  Mais lidas hoje
                </h2>
                <button
                  type="button"
                  onClick={onOpenFrontPage}
                  className="text-xs font-medium text-[#1E3A8A] hover:underline"
                >
                  Ver capa
                </button>
              </div>
              <ol className="mt-2 divide-y divide-stone-200">
                {relatedArticles.map((item, idx) => (
                  <li key={item.id} className="py-3.5 last:pb-0">
                    <button
                      type="button"
                      onClick={() => onSelectArticle(item.id)}
                      className="group block w-full text-left focus-visible:outline-2 focus-visible:outline-[#1E3A8A]"
                    >
                      <div className="flex items-baseline gap-3">
                        <span className="font-serif text-lg font-bold text-stone-400 tabular-nums">
                          0{idx + 1}
                        </span>
                        <div>
                          <p className="text-[11px] font-medium text-stone-500">
                            {item.section} · {item.readingMinutes} min
                          </p>
                          <h3 className="mt-1 font-serif text-sm font-semibold leading-snug text-[#161616] group-hover:text-[#1E3A8A] group-hover:underline">
                            {item.headline}
                          </h3>
                        </div>
                      </div>
                    </button>
                  </li>
                ))}
              </ol>
            </section>
          </div>
        </aside>
      </div>
    </main>
  );
}
