import { Bookmark, Search, X } from 'lucide-react';
import {
  filterArticles,
  type Article,
  type SectionCategory,
} from '../utils/editorial';

interface FrontPageViewProps {
  articles: Article[];
  activeSection: SectionCategory;
  searchQuery: string;
  onlySaved: boolean;
  savedIds: string[];
  onSearchChange: (q: string) => void;
  onToggleOnlySaved: () => void;
  onSelectSection: (section: SectionCategory) => void;
  onSelectArticle: (articleId: string) => void;
}

export function FrontPageView({
  articles,
  activeSection,
  searchQuery,
  onlySaved,
  savedIds,
  onSearchChange,
  onToggleOnlySaved,
  onSelectSection,
  onSelectArticle,
}: FrontPageViewProps) {
  const filtered = filterArticles(articles, activeSection, searchQuery, savedIds, onlySaved);

  const leadArticle = filtered.find((a) => a.tier === 'lead') ?? filtered[0];
  const secondaryFeatures = filtered.filter((a) => a.id !== leadArticle?.id).slice(0, 2);
  const archiveBriefs = filtered.filter(
    (a) => a.id !== leadArticle?.id && !secondaryFeatures.some((f) => f.id === a.id)
  );

  return (
    <main className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-8">
      {/* Edition Header & Working Search / Saved Controls */}
      <div className="flex flex-col gap-4 border-b border-stone-300 pb-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-medium text-stone-500">
            Edição Digital · {activeSection === 'Capa' ? 'Todas as Editorias' : activeSection}
          </p>
          <h1 className="mt-1 font-serif text-3xl font-bold tracking-tight text-[#161616] sm:text-4xl">
            {activeSection === 'Capa' ? 'Principais Reportagens do Dia' : activeSection}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[240px] flex-1 sm:w-64 sm:flex-initial">
            <label htmlFor="edition-search" className="sr-only">
              Buscar reportagens nesta edição
            </label>
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400"
              aria-hidden="true"
            />
            <input
              id="edition-search"
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Buscar reportagens..."
              className="min-h-[40px] w-full rounded border border-stone-300 bg-white py-2 pl-9 pr-8 text-sm text-[#161616] placeholder:text-stone-400 focus:border-[#1E3A8A] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                aria-label="Limpar busca"
                onClick={() => onSearchChange('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-[#161616]"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onToggleOnlySaved}
            aria-pressed={onlySaved}
            className={`inline-flex min-h-[40px] items-center gap-1.5 rounded border px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
              onlySaved
                ? 'border-[#1E3A8A] bg-[#1E3A8A] text-white'
                : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400 hover:text-[#161616]'
            }`}
          >
            <Bookmark className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Salvos ({savedIds.length})</span>
          </button>
        </div>
      </div>

      {/* Empty State */}
      {filtered.length === 0 ? (
        <section className="my-12 border border-stone-300 bg-white p-10 text-center">
          <h2 className="font-serif text-2xl font-semibold text-[#161616]">
            Nenhuma reportagem encontrada
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-stone-600">
            {onlySaved
              ? 'Você ainda não salvou matérias para leitura posterior ou sua busca não corresponde aos itens salvos.'
              : 'Não há publicações nesta editoria para os termos pesquisados.'}
          </p>
          <button
            type="button"
            onClick={() => {
              onSearchChange('');
              if (onlySaved) onToggleOnlySaved();
              onSelectSection('Capa');
            }}
            className="mt-6 min-h-[40px] rounded bg-[#161616] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E3A8A]"
          >
            Restaurar edição completa
          </button>
        </section>
      ) : (
        <div className="mt-8 space-y-10">
          {/* Tier 1: Dominant Lead Story */}
          {leadArticle && (
            <section aria-label="Manchete principal" className="border-b border-stone-300 pb-8">
              <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12">
                <div className="flex flex-col justify-between lg:col-span-5">
                  <div>
                    <p className="text-xs text-stone-500">
                      <span className={leadArticle.isBreaking ? 'font-semibold text-[#991B1B]' : 'font-semibold text-[#161616]'}>
                        {leadArticle.kicker}
                      </span>{' '}
                      · {leadArticle.section}
                    </p>
                    <h2 className="headline-balance mt-3 font-serif text-2xl font-bold leading-tight text-[#161616] sm:text-3xl">
                      <button
                        type="button"
                        onClick={() => onSelectArticle(leadArticle.id)}
                        className="text-left hover:text-[#1E3A8A] focus-visible:outline-2 focus-visible:outline-[#1E3A8A]"
                      >
                        {leadArticle.headline}
                      </button>
                    </h2>
                    <p className="mt-3 text-sm leading-relaxed text-stone-700 sm:text-base">
                      {leadArticle.deck}
                    </p>
                  </div>

                  <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-stone-200 pt-4 text-xs text-stone-500">
                    <span>
                      Por {leadArticle.authors} · {leadArticle.publishedAt}
                    </span>
                    <button
                      type="button"
                      onClick={() => onSelectArticle(leadArticle.id)}
                      className="font-semibold text-[#1E3A8A] hover:underline whitespace-nowrap shrink-0"
                    >
                      Ler reportagem completa
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-7">
                  <button
                    type="button"
                    onClick={() => onSelectArticle(leadArticle.id)}
                    aria-label={`Abrir matéria: ${leadArticle.headline}`}
                    className="block aspect-video h-full w-full overflow-hidden border border-stone-200 bg-[#EBE6DF]"
                  >
                    <img
                      src={leadArticle.heroImage.src}
                      alt={leadArticle.heroImage.alt}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover transition-transform duration-300 hover:scale-[1.01]"
                    />
                  </button>
                </div>
              </div>
            </section>
          )}

          {/* Tier 2: Secondary Features */}
          {secondaryFeatures.length > 0 && (
            <section aria-label="Destaques da edição" className="border-b border-stone-300 pb-8">
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
                {secondaryFeatures.map((item) => (
                  <article key={item.id} className="flex flex-col border border-stone-200 bg-white">
                    <button
                      type="button"
                      onClick={() => onSelectArticle(item.id)}
                      aria-label={`Abrir matéria: ${item.headline}`}
                      className="aspect-[4/3] w-full overflow-hidden bg-[#EBE6DF]"
                    >
                      <img
                        src={item.heroImage.src}
                        alt={item.heroImage.alt}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover transition-transform duration-300 hover:scale-[1.01]"
                      />
                    </button>
                    <div className="flex flex-1 flex-col justify-between p-6">
                      <div>
                        <p className="text-xs text-stone-500">
                          <span className="font-semibold text-[#161616]">{item.section}</span> ·{' '}
                          {item.kicker} · {item.readingMinutes} min
                        </p>
                        <h3 className="headline-balance mt-2 font-serif text-xl font-bold leading-snug text-[#161616]">
                          <button
                            type="button"
                            onClick={() => onSelectArticle(item.id)}
                            className="text-left hover:text-[#1E3A8A]"
                          >
                            {item.headline}
                          </button>
                        </h3>
                        <p className="mt-2 text-sm leading-relaxed text-stone-600">{item.deck}</p>
                      </div>

                      <p className="mt-4 border-t border-stone-100 pt-3 text-xs text-stone-500">
                        Por {item.authors} · {item.publishedAt}
                      </p>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          )}

          {/* Tier 3: Compact Department / Archive List */}
          {archiveBriefs.length > 0 && (
            <section aria-label="Arquivo e notas de editoria">
              <h2 className="border-b border-stone-300 pb-2 font-serif text-lg font-semibold text-[#161616]">
                Demais reportagens desta edição
              </h2>
              <div className="divide-y divide-stone-200">
                {archiveBriefs.map((item) => (
                  <article
                    key={item.id}
                    className="flex flex-col justify-between gap-4 py-5 sm:flex-row sm:items-center"
                  >
                    <div className="max-w-2xl">
                      <p className="text-xs text-stone-500">
                        <span className="font-semibold text-[#161616]">{item.section}</span> ·{' '}
                        {item.kicker} · {item.publishedAt} · {item.readingMinutes} min
                      </p>
                      <h3 className="mt-1 font-serif text-lg font-bold text-[#161616]">
                        <button
                          type="button"
                          onClick={() => onSelectArticle(item.id)}
                          className="text-left hover:text-[#1E3A8A] hover:underline"
                        >
                          {item.headline}
                        </button>
                      </h3>
                      <p className="mt-1 text-sm text-stone-600">{item.deck}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectArticle(item.id)}
                      className="min-h-[40px] self-start rounded border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-[#161616] hover:border-[#1E3A8A] hover:text-[#1E3A8A] whitespace-nowrap shrink-0 sm:self-center"
                    >
                      Ler matéria
                    </button>
                  </article>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </main>
  );
}
