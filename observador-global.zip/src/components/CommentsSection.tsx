import { useState, type FormEvent } from 'react';
import { ThumbsUp } from 'lucide-react';
import {
  sortComments,
  validateCommentInput,
  type CommentSortOrder,
  type ReaderComment,
} from '../utils/editorial';

interface CommentsSectionProps {
  comments: ReaderComment[];
  votedIds: string[];
  onToggleVote: (id: string) => void;
  onAddComment: (comment: ReaderComment) => void;
}

export function CommentsSection({
  comments,
  votedIds,
  onToggleVote,
  onAddComment,
}: CommentsSectionProps) {
  const [sortOrder, setSortOrder] = useState<CommentSortOrder>('top');
  const [author, setAuthor] = useState('');
  const [city, setCity] = useState('');
  const [body, setBody] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submittedNotice, setSubmittedNotice] = useState(false);

  const orderedComments = sortComments(comments, sortOrder);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const validation = validateCommentInput(author, city, body);
    if (!validation.valid) {
      setFormError(validation.error ?? 'Verifique os campos preenchidos.');
      setSubmittedNotice(false);
      return;
    }

    const newComment: ReaderComment = {
      id: `c-${Date.now()}`,
      author: author.trim(),
      city: city.trim(),
      createdAtIso: new Date().toISOString(),
      displayTime: 'agora mesmo',
      body: body.trim(),
      votes: 1,
    };

    onAddComment(newComment);
    setSortOrder('recent');
    setAuthor('');
    setCity('');
    setBody('');
    setFormError(null);
    setSubmittedNotice(true);
  };

  return (
    <section
      aria-labelledby="comments-heading"
      className="mt-12 border-t border-stone-300 pt-8"
    >
      <div className="flex flex-col gap-4 border-b border-stone-200 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 id="comments-heading" className="font-serif text-2xl font-semibold text-[#161616]">
            Comentários dos leitores ({comments.length})
          </h2>
          <p className="mt-1 text-xs text-stone-500">
            Espaço aberto para leitores e assinantes. Os comentários refletem exclusivamente a opinião de seus autores.
          </p>
        </div>

        <div className="inline-flex rounded bg-[#F4F1EA] p-1 shrink-0">
          <button
            type="button"
            onClick={() => setSortOrder('top')}
            className={`min-h-[36px] rounded px-3 py-1 text-xs font-semibold whitespace-nowrap transition-colors ${
              sortOrder === 'top'
                ? 'bg-white text-[#161616] shadow-xs'
                : 'text-stone-600 hover:text-[#161616]'
            }`}
          >
            Mais votados
          </button>
          <button
            type="button"
            onClick={() => setSortOrder('recent')}
            className={`min-h-[36px] rounded px-3 py-1 text-xs font-semibold whitespace-nowrap transition-colors ${
              sortOrder === 'recent'
                ? 'bg-white text-[#161616] shadow-xs'
                : 'text-stone-600 hover:text-[#161616]'
            }`}
          >
            Mais recentes
          </button>
        </div>
      </div>

      {/* Comment Submission Form */}
      <form
        onSubmit={handleSubmit}
        noValidate
        className="mt-6 border border-stone-200 bg-white p-5"
      >
        <h3 className="text-sm font-semibold text-[#161616]">Publicar comentário</h3>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="comment-author" className="block text-xs font-medium text-stone-700">
              Nome completo
            </label>
            <input
              id="comment-author"
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="Ex.: Marcelo Vieira"
              className="mt-1.5 min-h-[42px] w-full rounded border border-stone-300 bg-[#FAF9F6] px-3 py-2 text-sm text-[#161616] placeholder:text-stone-400 focus:border-[#1E3A8A] focus:bg-white focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="comment-city" className="block text-xs font-medium text-stone-700">
              Cidade / UF
            </label>
            <input
              id="comment-city"
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Ex.: São Paulo, SP"
              className="mt-1.5 min-h-[42px] w-full rounded border border-stone-300 bg-[#FAF9F6] px-3 py-2 text-sm text-[#161616] placeholder:text-stone-400 focus:border-[#1E3A8A] focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4">
          <label htmlFor="comment-body" className="block text-xs font-medium text-stone-700">
            Sua análise ou opinião
          </label>
          <textarea
            id="comment-body"
            rows={3}
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Escreva seu comentário sobre a reportagem..."
            className="mt-1.5 w-full rounded border border-stone-300 bg-[#FAF9F6] px-3 py-2 text-sm text-[#161616] placeholder:text-stone-400 focus:border-[#1E3A8A] focus:bg-white focus:outline-none"
          />
        </div>

        {formError && (
          <p role="alert" className="mt-3 text-xs font-medium text-[#991B1B]">
            {formError}
          </p>
        )}

        {submittedNotice && !formError && (
          <p role="status" className="mt-3 text-xs font-medium text-[#14532D]">
            Comentário publicado com sucesso na discussão da reportagem.
          </p>
        )}

        <div className="mt-4 flex items-center justify-between gap-4">
          <span className="text-xs text-stone-500 tabular-nums">{body.trim().length}/600 caracteres</span>
          <button
            type="submit"
            className="min-h-[40px] rounded bg-[#161616] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1E3A8A] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E3A8A]"
          >
            Enviar comentário
          </button>
        </div>
      </form>

      {/* Comments List */}
      <ul className="mt-6 divide-y divide-stone-200">
        {orderedComments.map((comment) => {
          const voted = votedIds.includes(comment.id);
          return (
            <li key={comment.id} className="py-5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div className="flex flex-wrap items-baseline gap-x-2 text-xs">
                  <span className="text-sm font-semibold text-[#161616]">{comment.author}</span>
                  {comment.role && (
                    <>
                      <span aria-hidden="true" className="text-stone-400">·</span>
                      <span className="font-medium text-stone-600">{comment.role}</span>
                    </>
                  )}
                  <span aria-hidden="true" className="text-stone-400">·</span>
                  <span className="text-stone-500">{comment.city}</span>
                </div>
                <span className="text-xs text-stone-500">{comment.displayTime}</span>
              </div>

              <p className="mt-2.5 text-sm leading-relaxed text-stone-800">{comment.body}</p>

              <div className="mt-3">
                <button
                  type="button"
                  onClick={() => onToggleVote(comment.id)}
                  aria-pressed={voted}
                  aria-label={`Recomendar comentário de ${comment.author}`}
                  className={`inline-flex min-h-[34px] items-center gap-1.5 rounded border px-2.5 py-1 text-xs font-medium tabular-nums transition-colors ${
                    voted
                      ? 'border-[#1E3A8A] bg-[#1E3A8A]/5 text-[#1E3A8A]'
                      : 'border-stone-300 bg-white text-stone-600 hover:border-stone-400 hover:text-[#161616]'
                  }`}
                >
                  <ThumbsUp className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Recomendar ({comment.votes})</span>
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
