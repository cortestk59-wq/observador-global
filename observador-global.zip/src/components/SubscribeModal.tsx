import { useState, type FormEvent } from 'react';
import { Check, X } from 'lucide-react';
import { validateNewsletterEmail } from '../utils/editorial';

interface SubscribeModalProps {
  open: boolean;
  subscribedEmail: string | null;
  onClose: () => void;
  onSubscribe: (email: string) => void;
}

export function SubscribeModal({
  open,
  subscribedEmail,
  onClose,
  onSubscribe,
}: SubscribeModalProps) {
  const [email, setEmail] = useState(subscribedEmail ?? '');
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const result = validateNewsletterEmail(email);
    if (!result.valid) {
      setError(result.error ?? 'E-mail inválido.');
      return;
    }
    setError(null);
    onSubscribe(email.trim());
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="subscribe-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
    >
      <div className="relative w-full max-w-md border border-stone-300 bg-[#FAF9F6] p-6 shadow-xl">
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar janela de assinatura"
          className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded border border-stone-300 bg-white text-stone-600 hover:text-[#161616]"
        >
          <X className="h-4 w-4" />
        </button>

        <p className="text-xs font-medium text-stone-500">Observador Global · Edição Digital</p>
        <h2
          id="subscribe-modal-title"
          className="mt-1 font-serif text-2xl font-bold text-[#161616]"
        >
          Receba os despachos de mercados e tecnologia
        </h2>
        <p className="mt-2 text-sm leading-relaxed text-stone-600">
          Alertas extraordinários de fatos relevantes da SEC, cobertura regulatória europeia e boletim matinal antes da abertura dos mercados.
        </p>

        {subscribedEmail ? (
          <div className="mt-5 border border-stone-300 bg-white p-4">
            <div className="flex items-start gap-2.5 text-sm text-[#14532D]">
              <Check className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              <div>
                <p className="font-semibold">Assinatura ativa confirmada</p>
                <p className="mt-1 text-xs text-stone-600">
                  Os boletins e alertas de última hora serão enviados para{' '}
                  <strong className="text-[#161616]">{subscribedEmail}</strong>.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="mt-4 min-h-[40px] w-full rounded bg-[#161616] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E3A8A]"
            >
              Continuar leitura
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-4">
            <div>
              <label htmlFor="newsletter-email" className="block text-xs font-medium text-stone-700">
                E-mail profissional ou pessoal
              </label>
              <input
                id="newsletter-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nome@empresa.com.br"
                className="mt-1.5 min-h-[42px] w-full rounded border border-stone-300 bg-white px-3 py-2 text-sm text-[#161616] placeholder:text-stone-400 focus:border-[#1E3A8A] focus:outline-none"
              />
            </div>

            {error && (
              <p role="alert" className="text-xs font-medium text-[#991B1B]">
                {error}
              </p>
            )}

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="min-h-[40px] rounded border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:text-[#161616]"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="min-h-[40px] rounded bg-[#161616] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E3A8A]"
              >
                Confirmar assinatura
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
