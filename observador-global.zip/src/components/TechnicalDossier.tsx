import { useState } from 'react';
import { type TechnicalTabKey } from '../utils/editorial';

const TABS: { key: TechnicalTabKey; label: string }[] = [
  { key: 'rage9', label: 'Parecer Técnico RAGE-9' },
  { key: 'sec8k', label: 'Protocolo SEC Form 8-K' },
  { key: 'market', label: 'Impacto NASDAQ: TTWO' },
];

export function TechnicalDossier() {
  const [activeTab, setActiveTab] = useState<TechnicalTabKey>('rage9');

  return (
    <section
      aria-label="Dossiê técnico e regulatório"
      className="my-8 border border-stone-300 bg-white p-5 sm:p-6"
    >
      <div className="border-b border-stone-200 pb-4">
        <p className="text-xs font-medium text-stone-500">
          Documentação de Suporte · Relatório de Auditoria e Mercado
        </p>
        <h2 className="mt-1 font-serif text-xl font-semibold text-[#161616]">
          Resumo dos bloqueios técnicos e financeiros confirmados
        </h2>
      </div>

      {/* Interactive Segmented Tabs */}
      <div
        role="tablist"
        aria-label="Seções do dossiê"
        className="mt-4 flex flex-wrap gap-1 rounded bg-[#F4F1EA] p-1"
      >
        {TABS.map((tab) => {
          const selected = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              type="button"
              role="tab"
              aria-selected={selected}
              onClick={() => setActiveTab(tab.key)}
              className={`min-h-[40px] flex-1 rounded px-3 py-2 text-xs font-semibold whitespace-nowrap transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-[#1E3A8A] ${
                selected
                  ? 'bg-white text-[#161616] shadow-xs'
                  : 'text-stone-600 hover:text-[#161616]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div className="mt-5" role="tabpanel">
        {activeTab === 'rage9' && (
          <div className="space-y-4">
            <p className="text-sm leading-relaxed text-stone-700">
              Registros de telemetria dos testes de homologação (Build <span className="font-mono text-xs">v1.04-RC7</span>) demonstraram exaustão progressiva de blocos contíguos de memória sob iluminação global por traçado de raios em áreas densas de Leonida.
            </p>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-300 text-stone-500">
                    <th className="py-2.5 pr-4 font-semibold">Plataforma</th>
                    <th className="py-2.5 pr-4 font-semibold">Orçamento Útil</th>
                    <th className="py-2.5 pr-4 font-semibold">Falha Observada</th>
                    <th className="py-2.5 font-semibold">Status Certificação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 tabular-nums">
                  <tr>
                    <td className="py-3 pr-4 font-medium text-[#161616]">Xbox Series S</td>
                    <td className="py-3 pr-4 font-mono">8,0 GB úteis</td>
                    <td className="py-3 pr-4 text-stone-700">
                      Estouro de VRAM e proteção térmica (42–47 min)
                    </td>
                    <td className="py-3 font-semibold text-[#991B1B]">Reprovado (XR-012)</td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-medium text-[#161616]">PlayStation 5 Base</td>
                    <td className="py-3 pr-4 font-mono">12,5 GB úteis</td>
                    <td className="py-3 pr-4 text-stone-700">
                      Saturação de descompressão E/S em voo rápido
                    </td>
                    <td className="py-3 font-semibold text-[#991B1B]">Retido (TRC R4088)</td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-medium text-[#161616]">Xbox Series X / PS5 Pro</td>
                    <td className="py-3 pr-4 font-mono">13,5–14,5 GB</td>
                    <td className="py-3 pr-4 text-stone-700">
                      Estável, bloqueado por cláusula de paridade
                    </td>
                    <td className="py-3 font-semibold text-stone-700">Suspenso por paridade</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'sec8k' && (
          <div className="space-y-4">
            <p className="text-sm leading-relaxed text-stone-700">
              Extrato dos itens 7.01 e 8.01 do Formulário 8-K protocolado pela Take-Two Interactive Software, Inc. junto à SEC em 16 de novembro de 2026.
            </p>
            <dl className="divide-y divide-stone-200 border-y border-stone-200 text-xs sm:text-sm">
              <div className="grid grid-cols-1 gap-1 py-3 sm:grid-cols-3">
                <dt className="font-semibold text-stone-500">Emissor / CIK</dt>
                <dd className="font-mono text-[#161616] sm:col-span-2">
                  Take-Two Interactive Software, Inc. (0000946581)
                </dd>
              </div>
              <div className="grid grid-cols-1 gap-1 py-3 sm:grid-cols-3">
                <dt className="font-semibold text-stone-500">Nova Janela Oficial</dt>
                <dd className="font-semibold text-[#161616] sm:col-span-2">
                  21 de outubro de 2027 (Q3 do Ano Fiscal 2028)
                </dd>
              </div>
              <div className="grid grid-cols-1 gap-1 py-3 sm:grid-cols-3">
                <dt className="font-semibold text-stone-500">Passivo Regulatório Citado</dt>
                <dd className="text-stone-700 sm:col-span-2">
                  Auditoria do EDPB (Art. 22 GDPR / Art. 50 EU AI Act) sobre variação prosódica de NPCs e aditivo de sincronização UMG / Social Club
                </dd>
              </div>
              <div className="grid grid-cols-1 gap-1 py-3 sm:grid-cols-3">
                <dt className="font-semibold text-stone-500">Política de Pré-venda</dt>
                <dd className="text-stone-700 sm:col-span-2">
                  Reembolso automático integral em até 10 dias úteis via lojas digitais e varejo credenciado
                </dd>
              </div>
            </dl>
          </div>
        )}

        {activeTab === 'market' && (
          <div className="space-y-4">
            <p className="text-sm leading-relaxed text-stone-700">
              Reação imediata dos ativos ligados ao ecossistema de entretenimento interativo no pregão eletrônico de pré-abertura em Nova York (10h10 BRT).
            </p>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-300 text-stone-500">
                    <th className="py-2.5 pr-4 font-semibold">Ativo / Ticker</th>
                    <th className="py-2.5 pr-4 font-semibold">Último Preço</th>
                    <th className="py-2.5 pr-4 font-semibold">Variação</th>
                    <th className="py-2.5 font-semibold">Leitura de Mesa</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 tabular-nums">
                  <tr>
                    <td className="py-3 pr-4 font-medium text-[#161616]">Take-Two (TTWO)</td>
                    <td className="py-3 pr-4 font-mono">US$ 143,85</td>
                    <td className="py-3 pr-4 font-mono font-semibold text-[#991B1B]">-14,82%</td>
                    <td className="py-3 text-stone-700">Corte de receita FY2027</td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-medium text-[#161616]">Sony Group (SONY)</td>
                    <td className="py-3 pr-4 font-mono">US$ 19,14</td>
                    <td className="py-3 pr-4 font-mono font-semibold text-[#991B1B]">-2,35%</td>
                    <td className="py-3 text-stone-700">Menor giro de hardware no Natal</td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-medium text-[#161616]">Electronic Arts (EA)</td>
                    <td className="py-3 pr-4 font-mono">US$ 151,20</td>
                    <td className="py-3 pr-4 font-mono font-semibold text-[#14532D]">+1,94%</td>
                    <td className="py-3 text-stone-700">Rotação defensiva no setor</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
