import { type Article, type ReaderComment } from '../utils/editorial';

export const LEAD_ARTICLE_ID = 'gta-vi-adiamento-2027';

export const ARTICLES: Article[] = [
  {
    id: LEAD_ARTICLE_ID,
    slug: 'falha-certificacao-consoles-impasse-ue-adiam-gta-vi-2027',
    section: 'Games & Mídia',
    kicker: 'Reportagem Especial · Última Hora',
    isBreaking: true,
    headline:
      'Falha de certificação de memória em consoles e impasse na UE adiam GTA VI para outubro de 2027',
    deck: 'Fato relevante enviado à SEC nesta segunda-feira confirma que a Take-Two Interactive suspendeu a estreia prevista para esta semana após o build Gold Master ser reprovado em testes térmicos e de alocação de VRAM no Xbox Series S e PS5; revisão regulatória europeia sobre síntese de voz amplia o cronograma.',
    authors: 'Rodrigo Alencar e Camila Vasconcelos',
    location: 'Nova York e Edimburgo',
    publishedAt: '16 nov 2026 · 08h42',
    updatedAt: 'Atualizado às 10h15',
    readingMinutes: 6,
    tier: 'lead',
    heroImage: {
      src: '/src/assets/images/hero_studio_headquarters_1794837221717.jpg',
      alt: 'Fachada de vidro e concreto da sede da Rockstar North em Edimburgo sob céu nublado',
      caption:
        'Fig. 1 — Sede operacional da Rockstar North, em Edimburgo, onde equipes de engenharia do motor RAGE-9 concentram a força-tarefa de reestruturação de memória.',
      credit: 'Foto: Callum MacLeod / Observador Global',
    },
    secondaryImage: {
      src: '/src/assets/images/article_console_lab_1794837222077.jpg',
      alt: 'Engenheiros realizando testes térmicos e de telemetria em kits de desenvolvimento de consoles em laboratório',
      caption:
        'Fig. 2 — Bancada de certificação com kits de desenvolvimento monitorados por câmeras térmicas e analisadores de barramento durante testes de estresse contínuo.',
      credit: 'Foto: Arquivo Técnico / Reuters',
    },
    leadParagraphs: [
      'A Take-Two Interactive Software protocolou às 06h58 (horário de Nova York) desta segunda-feira (16) um Formulário 8-K extraordinário junto à Comissão de Valores Mobiliários dos Estados Unidos (SEC) confirmando o adiamento do lançamento global de Grand Theft Auto VI para o dia 21 de outubro de 2027 — terceiro trimestre do ano fiscal de 2028 da companhia.',
      'A decisão ocorre a apenas três dias da janela comercial de novembro originalmente mantida pela publicadora e interrompe uma cadeia logística que já envolvia pré-carregamento parcial em servidores de distribuição digital e reservas físicas em varejistas da América do Norte e Europa.',
      'Segundo documentos técnicos anexados ao comunicado aos acionistas e apuração do Observador Global com três engenheiros ligados ao processo de homologação, a postergação não decorre de atraso criativo ou de conteúdo inacabado, mas de dois bloqueios simultâneos e juridicamente intransponíveis: a reprovação de última hora do candidato a lançamento (Release Candidate 7) nos laboratórios de certificação da Sony Interactive Entertainment e da Microsoft, somada a uma notificação cautelar emitida na sexta-feira pelo Comitê Europeu para a Proteção de Dados (EDPB).',
    ],
    pullQuote: {
      text: 'Não existe atualização de primeiro dia capaz de contornar uma violação de paginação de memória unificada em nível de kernel. Sem a assinatura de conformidade XR e TRC, o título é legalmente impedido de ser distribuído nas lojas digitais dos consoles.',
      attribution:
        'Marcus Vance, ex-diretor de certificação de plataforma e consultor da Omdia Research',
    },
    bodyParagraphs: [
      'O gargalo central reside na arquitetura de streaming assíncrono da versão 9 do motor gráfico RAGE (Rockstar Advanced Game Engine). Durante a bateria final de testes de estresse exigida pelos protocolos TRC (Technical Requirements Checklist) da Sony e XR (Xbox Requirements) da Microsoft, o build v1.04-RC7 apresentou falhas recorrentes de estouro de alocação no pool de memória unificada após 42 a 47 minutos de navegação contínua nas regiões centrais de Leonida.',
      'O problema atingiu de forma crítica o Xbox Series S — que opera com 10 GB de memória GDDR6 compartilhada entre sistema operacional, CPU e GPU, deixando cerca de 8 GB efetivos para aplicações —, onde a combinação de iluminação global por traçado de raios (RTGI), tráfego dinâmico de multidões e descompressão simultânea de texturas em alta densidade provocou fragmentação irreversível de VRAM e desligamentos preventivos por proteção térmica do SoC.',
      'Em paralelo, no PlayStation 5 padrão, picos de leitura superiores ao teto sustentável do controlador de E/S durante transições rápidas em veículos aéreos geraram travamentos de thread de áudio e corrupção temporária de geometria. Como os contratos de publicação vigentes proíbem o lançamento exclusivo ou assimétrico entre consoles da mesma família — exigindo paridade funcional entre Series X e Series S —, a Microsoft reteve o certificado de distribuição até a reescrita completa do escalonador de paginação de ativos.',
      'Engenheiros ouvidos pela reportagem explicam que reduzir simplesmente a distância de renderização ou a densidade de personagens não passou na auditoria interna da Rockstar Games por comprometer sistemas centrais de jogabilidade. A solução definitiva exige reconstruir o gerenciador de memória virtual do RAGE-9 e executar um novo ciclo completo de testes de regressão e certificação que consome entre sete e nove meses.',
    ],
    closingParagraphs: [
      'Para agravar o cronograma, o departamento jurídico da Take-Two recebeu na última sexta-feira um pedido formal de suspensão preventiva por parte de reguladores europeus em Bruxelas e de um consórcio ligado à Universal Music Publishing e ao sindicato SAG-AFTRA. Em questão está o sistema proprietário de variação prosódica em tempo real usado para gerar dezenas de milhares de reações contextuais de figurantes a partir de bancos fonéticos gravados por atores contratados.',
      'Autoridades europeias apontam que a técnica se enquadra nas obrigações de transparência e consentimento granular previstas no Artigo 50 da Lei de Inteligência Artificial da União Europeia (EU AI Act) e no Artigo 22 do GDPR, além de colidir com aditivos contratuais de sincronização musical para clipes exportados pelos usuários no Rockstar Social Club.',
      'Em teleconferência convocada às pressas com analistas de Wall Street às 09h15, o CEO Strauss Zelnick afirmou que a companhia "não negociará a estabilidade técnica em hardware de base nem assumirá passivos regulatórios na União Europeia que possam resultar em retirada do produto das lojas após a estreia". No pré-mercado da Nasdaq, os papéis da Take-Two (TTWO) despencavam 14,82% às 10h10, eliminando aproximadamente US$ 4,9 bilhões em valor de mercado. Varejistas e plataformas digitais confirmaram que os valores de pré-venda cobrados antecipadamente serão estornados automaticamente ao longo dos próximos dez dias úteis.',
    ],
    timeline: [
      {
        date: '04 nov 2026',
        title: 'Submissão do Release Candidate 7',
        detail:
          'Rockstar entrega o build v1.04-RC7 às bancadas de homologação da Sony (TRC) e Microsoft (XR).',
      },
      {
        date: '11 nov 2026',
        title: 'Falha térmica e estouro de VRAM no Series S',
        detail:
          'Testes de longa duração registram fragmentação crítica no pool de 8 GB disponíveis e desligamento por proteção do SoC.',
      },
      {
        date: '13 nov 2026',
        title: 'Notificação regulatória em Bruxelas',
        detail:
          'EDPB solicita auditoria sobre síntese prosódica de figurantes e travamento contratual de sincronização fonográfica.',
      },
      {
        date: '16 nov 2026 · 06h58',
        title: 'Protocolo Form 8-K na SEC',
        detail:
          'Take-Two oficializa adiamento para 21 de outubro de 2027 e aciona estorno global de pré-vendas.',
      },
    ],
    marketMetrics: [
      { label: 'Take-Two (NASDAQ: TTWO)', value: 'US$ 143,85', delta: '-14,82%', tone: 'negative' },
      { label: 'Valor de mercado perdido', value: 'US$ 4,92 bi', delta: 'Pré-mercado', tone: 'negative' },
      { label: 'Guidance Receita FY2027', value: 'US$ 5,45 bi', delta: 'Revisado (-31%)', tone: 'negative' },
      { label: 'Sony Group (NYSE: SONY)', value: 'US$ 19,14', delta: '-2,35%', tone: 'negative' },
      { label: 'Índice S&P 500 Tech', value: '4.812,40', delta: '+0,18%', tone: 'positive' },
    ],
  },
  {
    id: 'ttwo-reacao-wall-street',
    slug: 'wall-street-recalcula-receita-take-two-2027',
    section: 'Mercados',
    kicker: 'Bolsa de Nova York',
    headline:
      'Bancos de investimento cortam preço-alvo da Take-Two após deslocamento de receita de US$ 3,2 bi para FY2028',
    deck: 'Morgan Stanley, Wedbush e Jefferies revisam projeções de fluxo de caixa livre e alertam para efeito cascata no calendário publicitário do quarto trimestre.',
    authors: 'Henrique Tavares',
    location: 'Nova York',
    publishedAt: '16 nov 2026 · 09h50',
    readingMinutes: 4,
    tier: 'feature',
    heroImage: {
      src: '/src/assets/images/article_market_desk_1794837222634.jpg',
      alt: 'Operadores institucionais observam gráficos de queda em terminais de mercado financeiro',
      caption:
        'Fig. 1 — Mesa de renda variável em Manhattan acompanha abertura em forte baixa do setor de entretenimento interativo.',
      credit: 'Foto: Observador Global / Bloomberg Wire',
    },
    leadParagraphs: [
      'A revisão de cronograma anunciada pela Take-Two Interactive provocou uma onda imediata de rebaixamentos nas mesas de análise de Nova York antes mesmo do toque do sino de abertura da Nasdaq nesta segunda-feira.',
      'Em relatório distribuído a clientes institucionais às 08h10, o Morgan Stanley reduziu o preço-alvo da ação TTWO de US$ 210 para US$ 162, removendo aproximadamente US$ 3,2 bilhões em receita líquida estimada do quarto trimestre calendário de 2026 e transferindo o pico de geração de caixa para o exercício fiscal de 2028.',
    ],
    bodyParagraphs: [
      'O impacto não se restringe à publicadora norte-americana. Analistas apontam que varejistas de eletrônicos, fabricantes de televisores OLED e a própria divisão de hardware da Sony contavam com a estreia de novembro para impulsionar a renovação de consoles de meio de ciclo no varejo natalino.',
      'A dívida líquida da Take-Two, embora administrável após a emissão de notas sêniores em 2025, volta ao radar de agências de classificação de risco diante do custo adicional de nove meses de folha de pagamento para mais de 2.400 desenvolvedores envolvidos na refatoração do motor gráfico.',
    ],
    closingParagraphs: [
      'Para o gestor da Kestrel Asset Management, Daniel Sato, o movimento de venda observado pela manhã reflete a frustração de fundos posicionados em opções de vencimento curto, mas não altera a tese estrutural de longo prazo da franquia.',
    ],
    marketMetrics: [
      { label: 'Preço-alvo Morgan Stanley', value: 'US$ 162,00', delta: 'Antes: US$ 210', tone: 'negative' },
      { label: 'Volume Pré-Mercado', value: '18,4 mi ações', delta: '6,8x média', tone: 'neutral' },
    ],
  },
  {
    id: 'bruxelas-ai-act-sintese-vocal',
    slug: 'bruxelas-audita-sintese-vocal-entretenimento-digital',
    section: 'Regulação',
    kicker: 'União Europeia',
    headline:
      'Reguladores de Bruxelas apertam cerco sobre modelos prosódicos treinados com voz de atores em jogos AAA',
    deck: 'Parecer conjunto do EDPB e da Comissão Europeia exige rastreabilidade explícita de fonemas sintéticos sob pena de multa de até 4% do faturamento global.',
    authors: 'Sofia Mendonça',
    location: 'Bruxelas',
    publishedAt: '16 nov 2026 · 07h30',
    readingMinutes: 5,
    tier: 'feature',
    heroImage: {
      src: '/src/assets/images/article_brussels_council_1794837224484.jpg',
      alt: 'Plenário de audiência regulatória da União Europeia em Bruxelas com bancadas de madeira e microfones',
      caption:
        'Fig. 1 — Sala de audiências da diretoria de conformidade digital em Bruxelas, onde o parecer técnico foi protocolado na sexta-feira.',
      credit: 'Foto: Agência Europeia / Observador Global',
    },
    leadParagraphs: [
      'A entrada em plena vigência das penalidades administrativas da Lei de Inteligência Artificial da União Europeia (EU AI Act) neste segundo semestre de 2026 começou a produzir efeitos diretos sobre grandes produções de entretenimento interativo.',
      'Na última sexta-feira, o Comitê Europeu para a Proteção de Dados (EDPB) notificou três grandes conglomerados de software recreativo exigindo documentação detalhada de linhagem de dados sempre que falas dinâmicas de personagens não jogáveis forem interpoladas algoritmicamente fora de estúdio.',
    ],
    bodyParagraphs: [
      'Embora os estúdios argumentem que os modelos locais rodam integralmente no chip neural ou CPU do console sem conexão à nuvem nem coleta de dados do usuário final, juristas europeus sustentam que a geração de variações prosódicas inéditas a partir da identidade vocal de um intérprete exige consentimento granular por idioma e por contexto narrativo.',
      'Sindicatos de dubladores da França, Alemanha e Espanha protocolaram apoio à medida, pressionando para que qualquer linha de diálogo não gravada integralmente em estúdio seja desativada antes da comercialização no bloco.',
    ],
    closingParagraphs: [
      'Fontes em Bruxelas indicam que novas diretrizes setoriais serão publicadas até março de 2027, estabelecendo um padrão único de certificação biométrica para obras interativas distribuídas no Espaço Econômico Europeu.',
    ],
  },
  {
    id: 'series-s-limite-memoria-estudios',
    slug: 'engenharia-explica-gargalo-10gb-consoles-atuais',
    section: 'Tecnologia',
    kicker: 'Arquitetura de Hardware',
    headline:
      'Por que o teto de 10 GB de memória unificada se tornou o maior desafio de engenharia da atual geração',
    deck: 'Especialistas detalham como o compartilhamento entre sistema, ray tracing e streaming de texturas comprime margens de segurança no fim do ciclo dos consoles.',
    authors: 'Lucas Ferraz',
    location: 'São Paulo',
    publishedAt: '16 nov 2026 · 09h12',
    readingMinutes: 5,
    tier: 'brief',
    heroImage: {
      src: '/src/assets/images/article_console_lab_1794837222077.jpg',
      alt: 'Bancada técnica de testes térmicos e diagnóstico de memória de consoles',
      caption:
        'Fig. 1 — Equipamento de perfilamento de barramento e leitura térmica em laboratório de certificação.',
      credit: 'Foto: Arquivo Técnico / Reuters',
    },
    leadParagraphs: [
      'Projetados entre 2018 e 2019 e lançados em novembro de 2020, os consoles da nona geração entraram em seu sexto ano de mercado enfrentando uma restrição física difícil de mascarar apenas com escalonamento dinâmico de resolução: a capacidade absoluta de memória RAM.',
      'Enquanto placas dedicadas e estações de trabalho avançaram para 16 GB ou 24 GB exclusivos de VRAM, o modelo de entrada Xbox Series S dispõe de 10 GB unificados para todo o sistema — dos quais apenas cerca de 8 GB permanecem livres para o código do jogo, geometria, áudio e quadros de iluminação.',
    ],
    bodyParagraphs: [
      'Em mundos abertos densos com iluminação global calculada por traçado de raios em tempo real, o buffer de aceleração espacial (BVH) disputa espaço byte a byte com texturas em streaming de alta velocidade. Quando a fragmentação de memória impede a alocação contígua de um bloco crítico, o escalonador do console é obrigado a abortar a execução para preservar a integridade do sistema.',
    ],
    closingParagraphs: [
      'Segundo arquitetos de software gráfico, a saída adotada pela indústria envolve técnicas mais agressivas de paginação por blocos virtuais (virtual texturing) e compressão neural de ativos, medidas que exigem meses de validação para evitar degradação visual perceptível.',
    ],
  },
  {
    id: 'varejo-brasil-reembolso-prevenda',
    slug: 'varejistas-brasileiros-detalham-estorno-reservas-2026',
    section: 'Mercados',
    kicker: 'Consumo & Varejo',
    headline:
      'Varejistas e lojas digitais iniciam protocolo de estorno para mais de 420 mil reservas no Brasil',
    deck: 'Procon-SP e plataformas de pagamento acompanham devolução automática de edições físicas e digitais adquiridas para a janela de novembro.',
    authors: 'Mariana Duarte',
    location: 'São Paulo',
    publishedAt: '16 nov 2026 · 10h04',
    readingMinutes: 3,
    tier: 'brief',
    heroImage: {
      src: '/src/assets/images/article_market_desk_1794837222634.jpg',
      alt: 'Analistas monitoram impacto no varejo e setor de consumo',
      caption:
        'Fig. 1 — Setor de varejo de eletrônicos ajusta metas da Black Friday após adiamento.',
      credit: 'Foto: Observador Global',
    },
    leadParagraphs: [
      'Redes de varejo nacional e operadoras das lojas digitais PlayStation Store e Xbox Store Brasil iniciaram nesta manhã o processamento automático de estorno para pedidos em pré-venda de Grand Theft Auto VI.',
      'Estimativas da Associação Brasileira de Varejo de Tecnologia apontam que cerca de 420 mil unidades haviam sido reservadas antecipadamente no país desde a abertura do segundo lote promocional em agosto.',
    ],
    bodyParagraphs: [
      'Pelas regras da plataforma da Microsoft e da Sony, cobranças realizadas em cartão de crédito ou saldo em carteira digital para títulos com mudança superior a 90 dias na data oficial são canceladas sem necessidade de solicitação manual, salvo manifestação expressa do consumidor quando a nova janela for reaberta.',
    ],
    closingParagraphs: [
      'Lojistas que planejavam campanhas combinadas de consoles e periféricos para a última semana de novembro já redirecionam verbas de mídia para pacotes sazonais alternativos.',
    ],
  },
];

export const INITIAL_COMMENTS: ReaderComment[] = [
  {
    id: 'c-1',
    author: 'Eduardo Magalhães',
    city: 'Campinas, SP',
    role: 'Engenheiro de Sistemas Embarcados',
    createdAtIso: '2026-11-16T09:05:00Z',
    displayTime: 'há 52 min',
    body: 'Quem trabalha com alocação de memória em hardware fechado sabe que os 8 GB úteis do Series S são uma bomba-relógio desde 2023. Se o RAGE-9 estava batendo kernel panic depois de 45 minutos com RTGI ligado, não passa no XR da Microsoft nem com reza. Infelizmente é totalmente plausível.',
    votes: 184,
  },
  {
    id: 'c-2',
    author: 'Rafael Teixeira',
    city: 'Belo Horizonte, MG',
    createdAtIso: '2026-11-16T09:18:00Z',
    displayTime: 'há 39 min',
    body: 'Eu literalmente marquei duas semanas de férias no trabalho começando quinta-feira agora. Acabei de receber o link dessa matéria no grupo da firma e ainda estou tentando processar que só vai sair em outubro de 2027.',
    votes: 312,
  },
  {
    id: 'c-3',
    author: 'Patrícia Lemos',
    city: 'Lisboa, Portugal',
    role: 'Analista de Renda Variável',
    createdAtIso: '2026-11-16T09:34:00Z',
    displayTime: 'há 23 min',
    body: 'O Form 8-K antes da abertura explica o derretimento de quase 15% da TTWO no pré-mercado. Pior que o atraso técnico é essa frente jurídica na União Europeia sobre síntese de voz — quando Bruxelas trava licenciamento por AI Act, não existe patch rápido.',
    votes: 97,
  },
  {
    id: 'c-4',
    author: 'Thiago Nogueira',
    city: 'Curitiba, PR',
    createdAtIso: '2026-11-16T09:49:00Z',
    displayTime: 'há 14 min',
    body: 'A Sony e a Microsoft não deveriam obrigar paridade com hardware de 2020 de entrada para um jogo dessa escala. Já era previsível que a conta do Series S ia chegar na certificação Gold Master.',
    votes: 68,
  },
  {
    id: 'c-5',
    author: 'Bruno Almeida',
    city: 'São Paulo, SP',
    createdAtIso: '2026-11-16T10:02:00Z',
    displayTime: 'há 6 min',
    body: 'Melhor adiar para outubro de 2027 e entregar inteiro do que repetir o desastre de certificação de 2020 com jogo fechando sozinho no console. Mas que dói esperar mais 11 meses faltando três dias, dói demais.',
    votes: 41,
  },
];
