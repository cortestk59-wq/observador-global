import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateReadingMinutes,
  filterArticles,
  formatPctChange,
  sortComments,
  validateCommentInput,
  validateNewsletterEmail,
  type Article,
  type ReaderComment,
} from './editorial';

const sampleArticles: Article[] = [
  {
    id: 'a1',
    slug: 'gta-vi',
    section: 'Tecnologia',
    kicker: 'Exclusivo',
    headline: 'GTA VI adiado para 2027 por falha de memória',
    deck: 'Take-Two confirma nova janela após rejeição no Xbox Series S.',
    authors: 'Rodrigo Alencar',
    location: 'Nova York',
    publishedAt: '16 nov 2026',
    readingMinutes: 6,
    heroImage: { src: '/img1.jpg', alt: 'Campus', caption: 'Sede', credit: 'Reuters' },
    leadParagraphs: ['Parágrafo inicial.'],
    bodyParagraphs: ['Parágrafo intermediário.'],
    closingParagraphs: ['Conclusão.'],
    tier: 'lead',
  },
  {
    id: 'a2',
    slug: 'bc-selic',
    section: 'Mercados',
    kicker: 'Câmbio',
    headline: 'Dólar recua com ata do Copom',
    deck: 'Mercado precifica manutenção dos juros.',
    authors: 'Beatriz Ramos',
    location: 'São Paulo',
    publishedAt: '16 nov 2026',
    readingMinutes: 4,
    heroImage: { src: '/img2.jpg', alt: 'Mesa', caption: 'Mesa', credit: 'OG' },
    leadParagraphs: ['Texto mercado.'],
    bodyParagraphs: [],
    closingParagraphs: [],
    tier: 'feature',
  },
];

test('filterArticles filters by section and query case-insensitively', () => {
  assert.equal(filterArticles(sampleArticles, 'Capa', '').length, 2);
  assert.equal(filterArticles(sampleArticles, 'Mercados', '').length, 1);
  assert.equal(filterArticles(sampleArticles, 'Capa', 'series s').length, 1);
  assert.equal(filterArticles(sampleArticles, 'Regulação', '').length, 0);
});

test('filterArticles respects saved filter', () => {
  assert.equal(filterArticles(sampleArticles, 'Capa', '', ['a2'], true).length, 1);
  assert.equal(filterArticles(sampleArticles, 'Capa', '', [], true).length, 0);
});

test('sortComments orders by votes or recency', () => {
  const comments: ReaderComment[] = [
    {
      id: 'c1',
      author: 'Ana',
      city: 'SP',
      createdAtIso: '2026-11-16T09:00:00Z',
      displayTime: 'há 1h',
      body: 'Comentário antigo mas muito votado.',
      votes: 42,
    },
    {
      id: 'c2',
      author: 'Bruno',
      city: 'RJ',
      createdAtIso: '2026-11-16T10:30:00Z',
      displayTime: 'há 10min',
      body: 'Comentário recente com poucos votos.',
      votes: 3,
    },
  ];

  assert.equal(sortComments(comments, 'top')[0].id, 'c1');
  assert.equal(sortComments(comments, 'recent')[0].id, 'c2');
});

test('validateCommentInput rejects incomplete inputs and accepts valid comment', () => {
  assert.equal(validateCommentInput('Jo', 'SP', 'Texto longo suficiente').valid, false);
  assert.equal(validateCommentInput('João Silva', 'S', 'Texto longo suficiente').valid, false);
  assert.equal(validateCommentInput('João Silva', 'São Paulo', 'Curto').valid, false);
  assert.equal(
    validateCommentInput('João Silva', 'São Paulo', 'Já tinha tirado férias no trabalho em novembro.').valid,
    true
  );
});

test('validateNewsletterEmail validates email syntax', () => {
  assert.equal(validateNewsletterEmail('').valid, false);
  assert.equal(validateNewsletterEmail('invalido@').valid, false);
  assert.equal(validateNewsletterEmail('leitor@observador.com.br').valid, true);
});

test('calculateReadingMinutes and formatPctChange compute accurately', () => {
  const words = Array.from({ length: 400 }, () => 'palavra').join(' ');
  assert.equal(calculateReadingMinutes([words]), 3);
  assert.equal(formatPctChange(-14.82), '-14,82%');
  assert.equal(formatPctChange(2.5), '+2,50%');
});
