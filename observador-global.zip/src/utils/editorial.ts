export type SectionCategory =
  | 'Capa'
  | 'Mercados'
  | 'Tecnologia'
  | 'Games & Mídia'
  | 'Regulação';

export type TechnicalTabKey = 'rage9' | 'sec8k' | 'market';
export type CommentSortOrder = 'top' | 'recent';

export interface ArticleImage {
  src: string;
  alt: string;
  caption: string;
  credit: string;
}

export interface TimelineEvent {
  date: string;
  title: string;
  detail: string;
}

export interface MarketMetric {
  label: string;
  value: string;
  delta?: string;
  tone?: 'negative' | 'positive' | 'neutral';
}

export interface Article {
  id: string;
  slug: string;
  section: Exclude<SectionCategory, 'Capa'>;
  kicker: string;
  isBreaking?: boolean;
  headline: string;
  deck: string;
  authors: string;
  location: string;
  publishedAt: string;
  updatedAt?: string;
  readingMinutes: number;
  heroImage: ArticleImage;
  secondaryImage?: ArticleImage;
  leadParagraphs: string[];
  pullQuote?: {
    text: string;
    attribution: string;
  };
  bodyParagraphs: string[];
  closingParagraphs: string[];
  timeline?: TimelineEvent[];
  marketMetrics?: MarketMetric[];
  tier: 'lead' | 'feature' | 'brief';
}

export interface ReaderComment {
  id: string;
  author: string;
  city: string;
  role?: string;
  createdAtIso: string;
  displayTime: string;
  body: string;
  votes: number;
}

export function filterArticles(
  articles: Article[],
  section: SectionCategory,
  searchQuery: string,
  savedIds: string[] = [],
  onlySaved = false
): Article[] {
  const normalizedQuery = searchQuery.trim().toLowerCase();

  return articles.filter((article) => {
    if (onlySaved && !savedIds.includes(article.id)) {
      return false;
    }
    if (section !== 'Capa' && article.section !== section) {
      return false;
    }
    if (!normalizedQuery) {
      return true;
    }
    const haystack = [
      article.headline,
      article.deck,
      article.section,
      article.kicker,
      article.authors,
    ]
      .join(' ')
      .toLowerCase();

    return haystack.includes(normalizedQuery);
  });
}

export function sortComments(
  comments: ReaderComment[],
  order: CommentSortOrder
): ReaderComment[] {
  return [...comments].sort((a, b) => {
    if (order === 'top') {
      if (b.votes !== a.votes) {
        return b.votes - a.votes;
      }
      return b.createdAtIso.localeCompare(a.createdAtIso);
    }
    return b.createdAtIso.localeCompare(a.createdAtIso);
  });
}

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export function validateCommentInput(
  author: string,
  city: string,
  body: string
): ValidationResult {
  const cleanAuthor = author.trim();
  const cleanCity = city.trim();
  const cleanBody = body.trim();

  if (cleanAuthor.length < 3) {
    return {
      valid: false,
      error: 'Informe seu nome completo ou identificação (mínimo 3 caracteres).',
    };
  }
  if (cleanCity.length < 2) {
    return {
      valid: false,
      error: 'Informe sua cidade ou país de origem.',
    };
  }
  if (cleanBody.length < 12) {
    return {
      valid: false,
      error: 'O comentário precisa ter ao menos 12 caracteres.',
    };
  }
  if (cleanBody.length > 600) {
    return {
      valid: false,
      error: 'O comentário deve respeitar o limite máximo de 600 caracteres.',
    };
  }
  return { valid: true };
}

export function validateNewsletterEmail(email: string): ValidationResult {
  const clean = email.trim();
  if (!clean) {
    return {
      valid: false,
      error: 'Digite um endereço de e-mail válido para continuar.',
    };
  }
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!emailPattern.test(clean)) {
    return {
      valid: false,
      error: 'Formato de e-mail inválido. Exemplo: nome@empresa.com.br',
    };
  }
  return { valid: true };
}

export function calculateReadingMinutes(paragraphs: string[]): number {
  const totalWords = paragraphs
    .join(' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  return Math.max(1, Math.ceil(totalWords / 195));
}

export function formatPctChange(pct: number): string {
  const sign = pct > 0 ? '+' : '';
  return `${sign}${pct.toFixed(2).replace('.', ',')}%`;
}
